from flask import Flask
from main import app_main
from test import app_test
from misc import files_dir
import os
import random
import shutil
import string

app = Flask(__name__)

app.register_blueprint(app_main)
# TODO: Remove test stuff before release
app.register_blueprint(app_test)
app.secret_key = ''.join(random.choice(string.ascii_letters)
                         for _ in range(32))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8888)
