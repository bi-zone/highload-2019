from flask import Blueprint, current_app, request
from misc import auth_required
import requests

app_test = Blueprint('test',
                     __name__,
                     template_folder='templates',
                     url_prefix='/test')


@app_test.route('/test_action')
@auth_required
def test_action():
    r = requests.get(f'{request.host_url}action?'
                     f'secret={current_app.secret_key}'
                     f'&a={request.args.get("a", "list")}'
                     f'&username=test')
    return r.content
