from flask import current_app, redirect, request, session, url_for
from functools import wraps
import os

files_dir = 'files'


def auth_required(func):
    @wraps(func)
    def decorated_view(*args, **kwargs):
        if request.args.get('secret', '') == current_app.secret_key:
            session['username'] = request.args.get('username', 'test')
        if 'username' not in session:
            return redirect(url_for('main.new'))
        return func(*args, **kwargs)

    return decorated_view


def get_user_folder():
    return os.path.join(files_dir, session['username'])
