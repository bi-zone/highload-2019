from flask import Blueprint, abort, escape, session, redirect, render_template, request, url_for
from misc import auth_required, get_user_folder
import os
import random
import string

app_main = Blueprint('main',
                     __name__,
                     template_folder='templates',
                     url_prefix='')


@app_main.route('/')
def main():
    return render_template('index.html')


@app_main.route('/new')
def new():
    session['username'] = ''.join(random.choice(string.ascii_lowercase)
                                  for _ in range(12))
    try:
        os.makedirs(get_user_folder())
        with open(os.path.join(get_user_folder(), 'readme.txt'), 'w') as f:
            f.write('Thank you for join! Sorry, but file upload is currently unavailable.')
    except Exception as e:
        return abort(500, f'Error Creating User, Contact the Organizers [{str(e)}]')
    return redirect(url_for('main.action'))


@app_main.route('/action')
@auth_required
def action():
    action = request.args.get('a', default='home', type=str)

    if action == 'home':
        return render_template('body.html', action='home')
    elif action == 'list':
        return render_template('body.html', action='list', files=os.listdir(get_user_folder()))
        return f'Listing directory of user {session.get("username")}:<hr>'
    elif action == 'read':
        fname = request.args.get('file', '')
        if fname == '':
            return abort(400, 'No filename specified')
        ufolder = get_user_folder()
        fpath = os.path.normpath(os.path.join(ufolder, fname))
        if os.path.commonprefix((fpath, ufolder)) != ufolder:
            return abort(418, 'Hacking attempt')
        try:
            with open(os.path.join(get_user_folder(), fname)) as f:
                return f.read()
        except FileNotFoundError:
            return abort(404, 'Requested file not found')
        except Exception as e:
            return str(e)

    return abort(404, f'Action "{escape(action)}" not found')
